# Secure Browser (Android)

HTTPS-only WebView browser. Builds to an APK.

## Build the APK
1. Install Android Studio and open this folder.
2. Let Gradle sync finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Output: app/build/outputs/apk/debug/app-debug.apk

Or from a terminal (with the Android SDK installed): `gradle assembleDebug`

## Features
- HTTPS only: http:// links are upgraded, cleartext traffic is blocked
- Bad certificates are blocked, never bypassed
- Mixed content blocked
- Address bar with search fallback (DuckDuckGo)
- Back / forward / reload, progress bar
- Downloads files (including .apk) over HTTPS
- Can open https:// links from other apps

## No Android Studio? Build in the cloud (free)
1. Create a free GitHub account and a new repository.
2. Upload ALL files from this folder, including the hidden `.github` folder.
3. Open the Actions tab and wait for "Build APK" to finish (about 3-5 minutes).
4. Open the finished run and download the `SecureBrowser-apk` artifact (a zip containing app-debug.apk).
5. Unzip it, copy the APK to your phone, and install (allow "install unknown apps" when asked).
