# TEQSASUS Browser v3

Android browser project using the system Chromium-based Android WebView (Kotlin shell; web pages render with Chromium).

## Included in this update
- Multiple tabs: tab switcher, new tab, close current tab; Back closes a tab when its page has no back history.
- Search engine picker: DuckDuckGo, Google, Bing, Brave Search, and Ecosia. Selection is saved.
- Logo intro splash using `teqsasus_logo.png`.
- Existing bookmarks, history, HTTPS upgrade/blocking, and DownloadManager support retained.

## Build APK
Open this project in Android Studio and build, or push to GitHub and run the included Actions workflow. The output is an APK artifact.

Note: Android WebView is Chromium-based but is not the full desktop/mobile Chrome browser; Chrome Sync and extensions are not included.
