package com.example.securebrowser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.app.AlertDialog
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.Button
import android.widget.TextView
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var webContainer: FrameLayout
    private val tabs = mutableListOf<WebView>()
    private var activeTab = 0
    private var searchEngine = "DuckDuckGo"
    private val engines = linkedMapOf("DuckDuckGo" to "https://duckduckgo.com/?q=", "Google" to "https://www.google.com/search?q=", "Bing" to "https://www.bing.com/search?q=", "Brave" to "https://search.brave.com/search?q=", "Ecosia" to "https://www.ecosia.org/search?q=")

    private val home = "https://duckduckgo.com"
    private val searchUrl get() = engines[searchEngine] ?: engines["DuckDuckGo"]!!

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webContainer = findViewById(R.id.webContainer)
        web = createWebView()
        tabs.add(web)
        webContainer.addView(web)
        urlBar = findViewById(R.id.urlBar)
        progress = findViewById(R.id.progress)

        findViewById<TextView>(R.id.btnBack).setOnClickListener { if (web.canGoBack()) web.goBack() }
        findViewById<TextView>(R.id.btnForward).setOnClickListener { if (web.canGoForward()) web.goForward() }
        findViewById<TextView>(R.id.btnReload).setOnClickListener { web.reload() }
        findViewById<TextView>(R.id.btnHome).setOnClickListener { go(home) }
        findViewById<TextView>(R.id.btnTabs).setOnClickListener {
            showTabs()
        }
        findViewById<TextView>(R.id.btnBookmark).setOnClickListener { saveBookmark() }
        findViewById<TextView>(R.id.btnMenu).setOnClickListener { showBrowserMenu() }

        // WebViews are configured individually when each tab is created.

        web.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            download(url, userAgent, contentDisposition, mimeType)
        }

        urlBar.setOnEditorActionListener { v, actionId, event ->
            val enter = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                go(v.text.toString())
                true
            } else false
        }

        searchEngine = getSharedPreferences("teqasus", MODE_PRIVATE).getString("engine", "DuckDuckGo") ?: "DuckDuckGo"
        showIntro()
        go(intent?.data?.toString() ?: home)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(view: WebView) {
        with(view.settings) { javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = false; allowContentAccess = false; mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW; useWideViewPort = true; loadWithOverviewMode = true; setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false }
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, false)
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean { val u=request.url; return when(u.scheme){ "https"->false; "http"->{v.loadUrl(u.buildUpon().scheme("https").build().toString());true};else->true } }
            override fun onPageStarted(v: WebView, url: String, favicon: Bitmap?) { if(v===web && !urlBar.hasFocus()) urlBar.setText(url); title="TEQSASUS Browser"; if(v===web) progress.visibility=View.VISIBLE }
            override fun onPageFinished(v: WebView, url: String) { val prefs=getSharedPreferences("teqasus",MODE_PRIVATE); val h=prefs.getStringSet("history",emptySet())?.toMutableSet()?:mutableSetOf(); h.add(url); prefs.edit().putStringSet("history",h).apply(); if(v===web) progress.visibility=View.GONE }
            override fun onReceivedSslError(v: WebView, handler: SslErrorHandler, error: SslError) { handler.cancel(); showError("Connection not secure","The site's certificate could not be verified, so it was blocked.") }
            override fun onReceivedError(v: WebView, request: WebResourceRequest, error: WebResourceError) { if(request.isForMainFrame && v===web) showError("Can't load page",error.description.toString()) }
        }
        view.webChromeClient = object: WebChromeClient(){ override fun onProgressChanged(v:WebView,p:Int){ if(v===web){progress.progress=p;progress.visibility=if(p in 1..99) View.VISIBLE else View.GONE} } }
        view.setDownloadListener { url, ua, disposition, mime, _ -> download(url,ua,disposition,mime) }
    }

    private fun createWebView(): WebView = WebView(this).apply { configureWebView(this) }

    private fun showTabs() {
        val names=tabs.mapIndexed { i,v -> "${if(i==activeTab) "● " else "○ "}${v.title?.take(28)?.ifEmpty { "New tab" } ?: "New tab"}" }.toMutableList()
        names.add("＋ New tab")
        AlertDialog.Builder(this).setTitle("Tabs · ${tabs.size}").setItems(names.toTypedArray()){_,which->
            if(which==tabs.size) newTab(true) else switchTab(which)
        }.setNeutralButton("Close current tab"){_,_-> closeTab() }.show()
    }
    private fun newTab(loadHome:Boolean=true){ val v=createWebView(); tabs.add(v); switchTab(tabs.lastIndex); if(loadHome) v.loadUrl(home) }
    private fun switchTab(index:Int){ if(index !in tabs.indices)return; webContainer.removeView(web); activeTab=index; web=tabs[index]; webContainer.addView(web); urlBar.setText(web.url ?: ""); progress.visibility=View.GONE }
    private fun closeTab(){ if(tabs.size<=1){web.clearHistory();web.loadUrl(home);return}; val old=tabs.removeAt(activeTab); webContainer.removeView(old); old.stopLoading();old.destroy(); activeTab=(activeTab-1).coerceAtLeast(0); web=tabs[activeTab];webContainer.addView(web);urlBar.setText(web.url?:"") }
    private fun showEnginePicker(){ val labels=engines.keys.toTypedArray(); AlertDialog.Builder(this).setTitle("Search engine").setSingleChoiceItems(labels,labels.indexOf(searchEngine)){d,w-> searchEngine=labels[w];getSharedPreferences("teqasus",MODE_PRIVATE).edit().putString("engine",searchEngine).apply();Toast.makeText(this,"Search: $searchEngine",Toast.LENGTH_SHORT).show();d.dismiss() }.setNegativeButton("Cancel",null).show() }
    private fun showIntro(){ val overlay=FrameLayout(this);overlay.setBackgroundColor(android.graphics.Color.rgb(8,12,19));val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.gravity=android.view.Gravity.CENTER;val logo=ImageView(this);logo.setImageResource(R.drawable.teqsasus_logo);box.addView(logo,LinearLayout.LayoutParams(150,150));val name=TextView(this);name.text="TEQSASUS";name.textSize=26f;name.setTextColor(android.graphics.Color.WHITE);name.gravity=android.view.Gravity.CENTER;name.setPadding(0,24,0,0);box.addView(name);overlay.addView(box,FrameLayout.LayoutParams(-1,-1));addContentView(overlay,FrameLayout.LayoutParams(-1,-1));Handler(Looper.getMainLooper()).postDelayed({(overlay.parent as? android.view.ViewGroup)?.removeView(overlay)},1800) }

    private fun go(input: String) {
        val text = input.trim()
        if (text.isEmpty()) return
        val target = when {
            text.startsWith("https://", true) -> text
            text.startsWith("http://", true) -> "https://" + text.substring(7)
            !text.contains(" ") && text.contains(".") -> "https://$text"
            else -> searchUrl + Uri.encode(text)
        }
        web.loadUrl(target)
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    private fun saveBookmark() {
        val url = web.url ?: return
        val prefs = getSharedPreferences("teqsasus", MODE_PRIVATE)
        val old = prefs.getStringSet("bookmarks", emptySet())?.toMutableSet() ?: mutableSetOf()
        old.add(url)
        prefs.edit().putStringSet("bookmarks", old).apply()
        Toast.makeText(this, "Bookmark saved", Toast.LENGTH_SHORT).show()
    }

    private fun showBrowserMenu() {
        val options = arrayOf("Bookmarks", "History", "Share page", "Search engine: $searchEngine", "About TEQSASUS")
        AlertDialog.Builder(this).setTitle("TEQSASUS Browser").setItems(options) { _, which ->
            val prefs = getSharedPreferences("teqsasus", MODE_PRIVATE)
            when (which) {
                0 -> showSavedList("Bookmarks", prefs.getStringSet("bookmarks", emptySet())?.toList().orEmpty())
                1 -> showSavedList("History", prefs.getStringSet("history", emptySet())?.toList().orEmpty())
                2 -> { val send = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain").putExtra(android.content.Intent.EXTRA_TEXT, web.url); startActivity(android.content.Intent.createChooser(send, "Share page")) }
                3 -> showEnginePicker()
                4 -> AlertDialog.Builder(this).setTitle("TEQSASUS Browser").setMessage("A lightweight browser powered by Android Chromium WebView.").setPositiveButton("OK", null).show()
            }
        }.show()
    }

    private fun showSavedList(label: String, items: List<String>) {
        if (items.isEmpty()) { Toast.makeText(this, "No $label yet", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle(label).setItems(items.reversed().toTypedArray()) { _, index -> go(items.reversed()[index]) }.show()
    }

    private fun showError(title: String, message: String) {
        val html = "<html><body style='font-family:sans-serif;padding:24px'>" +
            "<h2>$title</h2><p>$message</p></body></html>"
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
    }

    // Handles file downloads, including .apk files. Tap the notification to install.
    private fun download(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        if (!url.startsWith("https://")) {
            Toast.makeText(this, "Blocked non-HTTPS download", Toast.LENGTH_SHORT).show()
            return
        }
        val name = URLUtil.guessFileName(url, contentDisposition, mimeType)
        val req = DownloadManager.Request(Uri.parse(url))
            .setMimeType(mimeType)
            .addRequestHeader("User-Agent", userAgent ?: "")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
        CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
        (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
        Toast.makeText(this, "Downloading $name", Toast.LENGTH_SHORT).show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else if(tabs.size>1) closeTab() else super.onBackPressed()
    }

    override fun onDestroy() {
        tabs.forEach { it.destroy() }
        super.onDestroy()
    }
}
